package com.example.gotani.util

object Constants {
    const val USER_COLLECTION = "user"
    const val INTRODUCTION_SP = "IntroductionSP"
    const val INTRODUCTION_KEY = "IntroductionKey"
}