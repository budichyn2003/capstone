package com.example.gotani

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class GotaniApplication: Application() {

}