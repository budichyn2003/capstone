CREATE TABLE orders (
    id INT AUTO_INCREMENT PRIMARY KEY NOT NULL,
    username VARCHAR(255) NOT NULL,
    orderItem INT(50) NOT NULL,
    shippingAddress VARCHAR(255) NOT NULL,
    quantity float NOT NULL,
    city VARCHAR(255) NOT NULL,
    totalPrice INT(15) NOT NULL,
    date VARCHAR(30) NOT NULL,
    statusOrder VARCHAR
);