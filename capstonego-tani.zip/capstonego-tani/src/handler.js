require('dotenv').config();

const mysql = require('mysql');
const inert = require('@hapi/inert');
const imgUploader = require('../modules/imgUploader.js');

const connection = mysql.createConnection({
    host: process.env.DB_HOST,
    user: process.env.DB_USER,
    database: process.env.DB_DATABASE,
    password: process.env.DB_PASSWORD,
    waitForConnections: true,
});

const postPhoto = async (request, h) => {
    try {
        const { payload } = request;
        const file = payload['image'];
    
        const cloudStoragePublicUrl = await imgUploader.uploadPhotos(file);
    
        const data = {
          imageUrl: cloudStoragePublicUrl,
        };
    
        return h.response(data).code(200).header('Content-Type', 'application/json'); // Update Content-Type
    
      } catch (error) {
        console.error("Error uploading image:", error);
        return h.response({ message: 'Error uploading image' }).code(500);
      }
  }; 

const addOrder = async (request, h) => {
    try {
        const payload = request.payload || {};
        const {username, orderItem, shippingAddress, quantity, city, totalPrice } = payload;

        if (!quantity) {
            const response = h.response({
                status: 'fail',
                message: 'Failed to insert a new order. Please fill in the quantity',
            });
            response.code(400);
            return response;
        }

        let orderItems;
        switch (orderItem) {
            case 'sayur':
                price = 1000 * quantity;
                break;
            case 'buah':
                price = 3000 * quantity;
                break;
            default:
                price = 0;
                break;
        }

        var imgUrl = '';
        if (request.file && request.file.cloudStoragePublicUrl) {
            imgUrl = request.file.cloudStoragePublicUrl;
        }
        
        const currentDate = new Date().toISOString();
        const date = currentDate.slice(0, 19).replace('T', ' ');
        const statusOrder = 'In package';

        const query = "INSERT INTO orders (username, orderItems, shippingAddress, quantity, city, statusOrder, totalPrice, date) VALUES (?, ?, ?, ?, ?, ?, ?)";
        const result = await new Promise((resolve, reject) => {
            connection.query(query, [username, orderItems, shippingAddress, quantity, city, statusOrder, totalPrice, imgUrl, date], (err, rows, fields) => {
                if (err) {
                    console.error("Database error:", err);
                    reject(err);
                } else {
                    resolve(rows);
                }
            });
        });

        return h.response({ message: "Insert Successful" });
    } catch (error) {
        console.error("Error:", error);
        return h.response({ message: "Failed insert into the database" }).code(500);
    }
};

const getAllOrders = async (request, h) => {
    try {
        const query = "SELECT * FROM orders";
        const result = await new Promise((resolve, reject) => {
            connection.query(query, (err, rows, fields) => {
                if (err) {
                    reject(err);
                } else {
                    resolve(rows);
                }
            });
        });

        return h.response(result);
    } catch (error) {
        console.error("Error:", error);
        return h.response({ message: "Failed to retrieve orders" }).code(500);
    }
};

const getOrderById = async (request, h) => {
    const id  = request.params.id;
    try {
        const query = "SELECT * FROM orders WHERE id = ?"
        const result = await new Promise((resolve, reject) => {
            connection.query(query, [id], (err, rows, fields) => {
                if (err) {
                    reject(err);
                } else {
                    resolve(rows);
                }
            });
        });

        // No orders found
        if (result.length === 0) {
            return h.response({ message: "No orders found" }).code(404);
        }

        return h.response(result);
    } catch (error) {
        console.error("Error:", error);
        return h.response({ message: "Failed to retrieve orders" }).code(500);
    }
}

const getTotalPrice = async (request, h) => {
    const username = request.params.username;

    try {
        const query = "SELECT SUM(price) AS total_price FROM orders WHERE username = ?";
        
        const result = await new Promise((resolve, reject) => {
            connection.query(query, [username], (err, rows, fields) => {
                if (err) {
                    reject(err);
                } else {
                    resolve(rows);
                }
            });
        });

        if (result.length === 0) {
            return h.response({ message: "No orders found for the specified username" }).code(404);
        }

        return h.response(result[0]);
    } catch (error) {
        console.error("Error:", error);
        return h.response({ message: "Failed to retrieve total price" }).code(500);
    }
};


const canceledStatus = async (request, h) => {
    const id = request.params.id;
    try {
        const query = "UPDATE orders SET status = 'Canceled' WHERE id = ? AND status != 'Completed'";
        const result = await new Promise((resolve, reject) => {
            connection.query(query, [id], (err, rows, fields) => {
                if (err) {
                    reject(err);
                } else {
                    resolve(rows);
                }
            });
        });

        // No orders found 
        if (result.length === 0) {
            return h.response({ message: "No orders found" }).code(404);
        }

        return h.response(result);
    } catch (error) {
        console.error("Error:", error);
        return h.response({ message: "Failed to update order status" }).code(500);
    }
}

const completedStatus = async (request, h) => {
    const id = request.params.id;
    try {
        const query = "UPDATE orders SET status = 'Completed' WHERE id = ? && status != 'Canceled'";
        const result = await new Promise((resolve, reject) => {
            connection.query(query, [id], (err, rows, fields) => {
                if (err) {
                    reject(err);
                } else {
                    resolve(rows);
                }
            });
        });

        // No orders found 
        if (result.length === 0) {
            return h.response({ message: "No orders found" }).code(404);
        }

        return h.response(result);
    } catch (error) {
        console.error("Error:", error);
        return h.response({ message: "Failed to update order status" }).code(500);
    }
}

const deleteOrder = async (request, h) => {
    const id = request.params.id;
    try {
        const query = "DELETE FROM orders WHERE id = ?"
        const result = await new Promise((resolve, reject) => {
            connection.query(query, [id], (err, rows, fields) => {
                if (err) {
                    reject(err);
                } else {
                    resolve(rows);
                }
            });
        });

        // No orders found 
        if (result.affectedRows === 0) {
            return h.response({ message: "No orders found" }).code(404);
        }

        return h.response(result);
    } catch (error) {
        console.error("Error:", error);
        return h.response({ message: "Failed to delete order status" }).code(500);
    }
}

module.exports = {
    postPhoto,
    addOrder,
    getAllOrders,
    getOrderById,
    canceledStatus,
    completedStatus,
    getTotalPrice,
    deleteOrder
};
