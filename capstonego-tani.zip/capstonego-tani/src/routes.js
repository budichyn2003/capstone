const { postPhoto, addOrder, getAllOrders, getOrderById, canceledStatus, completedStatus, getTotalPrice, deleteOrder} = require('./handler');

const routes = [
    {
      method: 'POST',
      path: '/orders',
      handler: addOrder,
    },

    {
      method: 'POST',
      path: '/photos',
      handler: postPhoto
    },

    {
      method: 'GET',
      path: '/orders',
      handler: getAllOrders,
    },

    {
      method: 'GET',
      path: '/orders/{id}',
      handler: getOrderById,
    },

    {
      method: 'GET',
      path: '/orders/{username}/totalprice',
      handler: getTotalPrice
    },

    {
      method: 'PUT',
      path: '/orders/{id}/completed',
      handler: completedStatus,
    },

    {
      method: 'PUT',
      path: '/orders/{id}/canceled',
      handler: canceledStatus,
    },
    {
      method: 'DELETE',
      path: '/orders/{id}',
      handler: deleteOrder
    }

]
module.exports = routes;